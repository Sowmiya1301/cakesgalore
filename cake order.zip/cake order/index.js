let search = document.querySelector('.search');
document.querySelector('#search').onclick=() =>{
    search.classList.toggle('active');
    cart.classList.remove('active');
}

let cart = document.querySelector('.cart-items-container');
document.querySelector('#cart').onclick=() =>{
    cart.classList.toggle('active');
    search.classList.remove('active');
}